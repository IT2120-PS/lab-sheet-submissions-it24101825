setwd("C:\\Users\\it24101825\\Desktop\\IT24101825")

data <- read.table("DATA 4.txt", header = TRUE, sep = " ")

fix(data)

attach(data)


boxplot(X1, main = "Box plot for Team Attendence", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X2, main = "Box plot for Team Salary", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X3, main = "Box plot for Years", outline = TRUE, outpch = 8, horizontal = TRUE)


hist(X1, ylab = "Frequency", xlab = "Team Attendence", main = "Histogram for Team Attendence")
hist(X2, ylab = "Frequency", xlab = "Team Salary", main = "Histogram for Team Salary")
hist(X3, ylab = "Frequency", xlab = "Years", main = "Histogram for Years")

# Stem & Leaf Plot
stem(X1)
stem(X2)
stem(X3)
